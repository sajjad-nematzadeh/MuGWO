function MuDrawPlots(x,l,adjacencyMatrix,occupation,map,G,transmissionRange, sensingRange, heightOfEnvironment, widthOfEnvironment,pName)
global coverageImportanceMap;global isCustomMap;
occupation=uint8(255*occupation);
drawGraph=0;drawOccupancy=0;
% map dimensions to nodes
n=size(x,2)/2;
nodes=zeros(n,2);
for i=1:n
    nodes(i,1)=x(i*2-1);
    nodes(i,2)=x(i*2);
end

margin=20;

clf(figure(1));
figure(1);
hold on;scatter(nodes(:,1),nodes(:,2),'magenta','filled');
if isCustomMap==1
% matI = uint8(ones(heightOfEnvironment,widthOfEnvironment))*255;
% rgbImage(:,:,1)= matI - coverageImportanceMap;
% rgbImage(:,:,2)= matI - coverageImportanceMap;
% rgbImage(:,:,3)= matI - coverageImportanceMap;

rgbImage(:,:,1)= coverageImportanceMap;
rgbImage(:,:,2)= coverageImportanceMap;
rgbImage(:,:,3)= coverageImportanceMap;

rgbImage=imadjust(rgbImage,[0,1],[0.5,1]);
hold on;imshow(rgbImage);
end
% Environment Visualization
for i=1:n
    x=nodes(i,1)-sensingRange ;
    y=nodes(i,2)-sensingRange;
    r=sensingRange*2;
    hold on;rectangle('Position',[x y r r],'Curvature',[1 1],'FaceColor',[1 1 .8 0.6]);
end
for i=1:n
    
    %transmission
   
    x=nodes(i,1)-transmissionRange ;
    y=nodes(i,2)-transmissionRange;
    r=transmissionRange*2;
     hold on;rectangle('Position',[x y r r],'Curvature',[1 1],'EdgeColor',[.7 .7 1 .8],'LineWidth',0.1);
    
    %sensing
    
    x=nodes(i,1)-sensingRange ;
    y=nodes(i,2)-sensingRange;
    r=sensingRange*2;
    hold on;rectangle('Position',[x y r r],'Curvature',[1 1],'EdgeColor',[0.8 0.8 .6],'LineWidth',0.5);
    
 
    for j=i+1:n
        if(adjacencyMatrix(i,j)==1)
            hold on;plot([nodes(i,1),nodes(j,1)],[nodes(i,2),nodes(j,2)],'-r.')
        end
    end
   
end
% for i=1:n
%     hold on;viscircles([nodes(i,1),nodes(i,2)], 10,'LineWidth',5,'color','m');
% end
hold on;scatter(nodes(:,1),nodes(:,2),'black','filled');


ylim([-margin heightOfEnvironment+margin]);
xlim([-margin widthOfEnvironment+margin]);
hold off;
% if(mod(l,saveImagePer)==1)
    print(['Plots/' pName '_NDMap_' num2str(l)],'-dpng','-r300')
% end

figure(4);
occMap=imcomplement(flip(occupation,1));
occMap=imadjust(occMap,[0,1],[0,0.5]);
imshow(255-occMap);

% if(mod(l,saveImagePer)==1)
    print(['Plots/' pName '_occMap_' num2str(l)],'-dpng','-r300')
% end


% Graph Visualization

if drawGraph==1
    figure(2)
    hold off;plot(G);
end


% Occupancy mapping
if drawOccupancy==1
    figure(3)
    show(map)
end

end