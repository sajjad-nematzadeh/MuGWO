% This function initialize the first population of search agents
function Positions=MuInitializer(SearchAgents_no,dim,heightOfEnvironment,widthOfEnvironment, freedomRate)

Positions=zeros(SearchAgents_no,dim);

for i=1:SearchAgents_no
    for j=1:2:dim
        Positions(i,j)=widthOfEnvironment/2 + (2*rand()-1)*widthOfEnvironment*freedomRate*0.5; % x
        Positions(i,j+1)=heightOfEnvironment/2 + (2*rand()-1)*heightOfEnvironment*freedomRate*0.5; % y
    end
end

end