clear all;clc;
SearchAgents_no=100;    % Number of search agents
mutationDimensions=2;	% Number of dimensions for mutation
Max_iter=500;           % Maximum numbef of iterations

widthOfEnvironment=50;  % Bounds of environment
heightOfEnvironment=50; %
resolution = 1;         %
n=50;dim=n*2;           % Number of nodes and corresponded dimensions
fitnessFnc=@MuFitness;	% Fitness function
transmissionRange=15;	% Range of transmitter
sensingRange = 5;       % Range of sensor
degFree=0.3;
runs=10;
global isCustomMap;isCustomMap=1;

global coverageImportance;global coverageImportanceMap;
if isCustomMap==1
    coverageImportanceMap = MuReadMap('Maps\geo_1.bmp');
    coverageImportance = sepblockfun((double(coverageImportanceMap))/255, [ (1/resolution), (1/resolution)], 'mean');
    coverageImportance = flip(coverageImportance,1);
    widthOfEnvironment=size(coverageImportance,2);  % 
    heightOfEnvironment=size(coverageImportance,1); %
else
    coverageImportance=zeros(heightOfEnvironment*resolution,widthOfEnvironment*resolution)+1;
end
global saveImagePer;saveImagePer=20;
global darwPlotsPer;darwPlotsPer=25;

%%%%%%%%%%%%%%%%%%%%%%%% m
%%%%%%%%%
 
 sensingRange = 100;transmissionRange=sensingRange*2;

%%%%%%%%%%%%%%%%%%%% Mu-GWO
mutationCount=30;       % Count of wolfs to have mutant copies of alpha
n=38;dim=n*2;           % Number of nodes and corresponded dimensions
for i=1:runs
    pName=['geo_1_100_200_38_m_' num2str(i)];
    MuGWO(SearchAgents_no,Max_iter,dim,fitnessFnc,mutationCount,mutationDimensions, transmissionRange, sensingRange,heightOfEnvironment,widthOfEnvironment,resolution,degFree,pName)
end



sensingRange = 100;transmissionRange=sensingRange*2;
%%%%%%%%%%%%%%%%%%% Original GWO
mutationCount=0;
n=38;dim=n*2;           % Number of nodes and corresponded dimensions
for i=1:runs
    pName=['geo_1_100_200_38_o_' num2str(i)];
    MuGWO(SearchAgents_no,Max_iter,dim,fitnessFnc,mutationCount,mutationDimensions, transmissionRange, sensingRange,heightOfEnvironment,widthOfEnvironment,resolution,degFree,pName)
end
