
lb=0;ub=1000;
d=2000;
n=80;sr=50;margin=0;
idx=1;
cla(figure(1));
figure(1);
offset=0;
nodes=zeros(n,2);
resolution=1;
isCustomMap=1;
widthOfEnvironment=5;
heightOfEnvironment=5;
if isCustomMap==1
    coverageImportanceMap = MuReadMap('Maps\geo_1.bmp');
%     coverageImportance = sepblockfun(double(coverageImportanceMap)/255, [0.5,0.5], 'mean');
%     coverageImportance = sepblockfun((double(coverageImportanceMap))/255, [ (1/resolution), (1/resolution)], 'mean');
%     coverageImportanceMap=rot90(rot90(coverageImportanceMap));
%     coverageImportance = flip(coverageImportance);
    widthOfEnvironment=size(coverageImportance,2);  % 
    heightOfEnvironment=size(coverageImportance,1); %
else
    coverageImportance=zeros(heightOfEnvironment*resolution,widthOfEnvironment*resolution)+1;
end
hold on;rectangle('Position',[nodes(1,1)-sr nodes(1,2)-sr sr*2 sr*2],'Curvature',[1 1],'EdgeColor',[0.8 0.8 .6],'LineWidth',0.5,'FaceColor',[1 1 .8 0.6]);

if isCustomMap==1
% matI = uint8(ones(heightOfEnvironment,widthOfEnvironment))*255;
% rgbImage(:,:,1)= matI - coverageImportanceMap;
% rgbImage(:,:,2)= matI - coverageImportanceMap;
% rgbImage(:,:,3)= matI - coverageImportanceMap;

rgbImage(:,:,1)= coverageImportanceMap;
rgbImage(:,:,2)= coverageImportanceMap;
rgbImage(:,:,3)= coverageImportanceMap;

% rgbImage=imadjust(rgbImage,[0,1],[0.5,1]);
hold on;imshow(rgbImage);
end
x=0;y=sqrt(3/4)*sr;sgn=1;
if(isCustomMap==1)
    y=heightOfEnvironment-y;
    sgn=-1;
end


row=1;
nodes(1,1)=x;
nodes(1,2)=y;
% nodes(2,1)=d;
% nodes(2,2)=y;
hold on;rectangle('Position',[nodes(1,1)-sr nodes(1,2)-sr sr*2 sr*2],'Curvature',[1 1],'EdgeColor',[0.8 0.8 .6],'LineWidth',0.5,'FaceColor',[1 1 .8 0.6]);
% rectangle('Position',[nodes(2,1)-sr nodes(2,2)-sr sr*2 sr*2],'Curvature',[1 1],'EdgeColor',[0.8 0.8 .6],'LineWidth',0.5,'FaceColor',[1 1 .8 0.6]);
tm=widthOfEnvironment-sr*floor(widthOfEnvironment/sr);
if(tm>(sr/2))
    firstLineSupport=0;
else
    firstLineSupport=1;
end
while(idx<n)
    x=x+sr;
    if(x>widthOfEnvironment)
        if(firstLineSupport==0)
            x=widthOfEnvironment;
            offset=sr/2;
            firstLineSupport=1;
        else
            if(mod(row,2)==0)
                offset=0;
            else
                offset=sr/2;
            end
            y=y+sqrt(3/4)*sr*sgn;
            %y=y+sr;
            x=offset;
            row=row+1;
        end
        
    end
    idx=idx+1;
    nodes(idx,1)=x;
    nodes(idx,2)=y;
    rectangle('Position',[x-sr y-sr sr*2 sr*2],'Curvature',[1 1],'EdgeColor',[0 0 0 0.4],'LineWidth',0.5,'FaceColor',[1 0.9 0.9 0.4]);
end

scatter(nodes(:,1),nodes(:,2),'black','filled');

ylim([-margin heightOfEnvironment+margin]);
xlim([-margin widthOfEnvironment+margin]);
hold off;

%figure(2);
map = binaryOccupancyMap(widthOfEnvironment,heightOfEnvironment,resolution);
setOccupancy(map,[nodes(:,1) nodes(:,2)], 1);
inflate(map,sr);
% occmap = occupancyMatrix(map);
occmap = occupancyMatrix(map).* coverageImportance;
figure(2)
imshow(occmap);

% cr=(sum(sum(occmap))/length(occmap)^2);
cr=sum(sum(occmap))/sum(sum(coverageImportance));

oc=cr*d^2;
display(oc);
display(cr);
% function [outputArg1,outputArg2] = Analytic(inputArg1,inputArg2)
% 
% viscircles([nodes(i,1),nodes(i,2)], transmissionRange,'LineWidth',0.5,'color','c');
% end

