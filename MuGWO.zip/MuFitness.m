function o = MuFitness(x,l,transmissionRange, sensingRange, resolution,heightOfEnvironment,widthOfEnvironment,isDraw,isPrint,pName)
global coverageImportance;

% resterictionPenalty
penalty=heightOfEnvironment*widthOfEnvironment;totalDistance=0;

% map dimensions to nodes (2 dimensions for x and y of the position of each node)
n=size(x,2)/2;
nodes=zeros(n,2);
for i=1:n
    nodes(i,1)=x(i*2-1);
    nodes(i,2)=x(i*2);
end

% ########### Generating the topology graph
distanceMatrix=dist(nodes');
adjacencyMatrix=distanceMatrix<=transmissionRange;


for i=1:n;adjacencyMatrix(i,i)=0;end

% Graph generation and Visualization
G = graph(adjacencyMatrix);

% Calculating disconnected subgraphs
bins = conncomp(G);sepGraphCount = numel(accumarray(bins', 1:numel(bins), [], @(v) {sort(v')}));
dc=sepGraphCount-1;
edges=table2array(G.Edges);
maxDegree=sum(bins(:) == mode(bins));
degreeRate=maxDegree/n;

% Calculating connected distances
for i=1:size(G.Edges,1)
    totalDistance=totalDistance+distanceMatrix(edges(i,1),edges(i,2));
end

% ################## Calculating sensing coverage
% Occupancy mapping
% figure(3)
map = binaryOccupancyMap(widthOfEnvironment,heightOfEnvironment,resolution);
setOccupancy(map,[nodes(:,1) nodes(:,2)], 1);
inflate(map,sensingRange);
% show(map)

% Coverage rate
mapSize=sum(sum(coverageImportance));
occupation = occupancyMatrix(map).* coverageImportance;
coverageReward=sum(sum(occupation));
cr = coverageReward/mapSize;



% claculating fitness
%Equation 7
%fitness= (1+dc*penalty)/totalDistance;

%Equation 8
%fitness= ((1+dc*penalty)+size(G.Edges,1))/totalDistance;

%Equation 11
a=40;b=5;c=1;
fitness= (size(G.Edges,1)+dc*penalty)/(a*cr+b*degreeRate+c*totalDistance)-a*cr;

if  isPrint==1
    %Iteration, CoverageRate, TotalDistance, DiscoennectedParts, MaxDegree,
    %Fitness, 

    disp("Disconnected parts:"+dc+", fitness: "+fitness+" , Coverage Rate:"+(cr*100)+"%");
    N=[l cr totalDistance dc maxDegree fitness ];
    
    dlmwrite(['Results/' pName '_res.csv'],N,'delimiter',',','-append');
end 

if  (isDraw ==1)
    MuDrawPlots(x,l,adjacencyMatrix,occupation,map,G,transmissionRange, sensingRange, heightOfEnvironment, widthOfEnvironment,pName)
end
o=fitness;
end