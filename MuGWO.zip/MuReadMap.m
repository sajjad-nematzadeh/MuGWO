function map = MuReadMap(fileName)
    map=rgb2gray(imread(fileName));
end

